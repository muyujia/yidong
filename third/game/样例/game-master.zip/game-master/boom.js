/*
* cobj  2d对象
* obj   爆炸对象
* */
